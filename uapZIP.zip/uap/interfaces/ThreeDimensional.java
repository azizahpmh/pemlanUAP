package uap.interfaces;

public interface ThreeDimensional {
    double getSurfaceArea();
    double getVolume();
}