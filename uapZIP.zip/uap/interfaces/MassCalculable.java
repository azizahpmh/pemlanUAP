package uap.interfaces;

public interface MassCalculable {
    int DENSITY = 8;
    double THICKNESS = 0.5;
    double getMass();
}