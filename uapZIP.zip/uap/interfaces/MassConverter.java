package uap.interfaces;

public interface MassConverter {
    int DENOMINATOR = 1000;
    double gramToKilogram();
}