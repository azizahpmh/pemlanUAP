package uap.interfaces;

public interface PiRequired {
    double PI = 22.0 / 7.0;
}